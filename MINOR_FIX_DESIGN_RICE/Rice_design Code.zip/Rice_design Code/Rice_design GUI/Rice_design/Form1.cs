﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;

namespace Rice_design
{
    public partial class Form1 : Form
    {
        Logic log = new Logic();


        public static Form1 _Form1;
        public Form1()
        {
            InitializeComponent();
            _Form1 = this;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //trans
            log.Dis();
            log.Con();
            log.Trans(out string count, out string[] words);
            
            richTextBox1.AppendText("\n" + count + " - " + "      Moisture: " + words[0] + "      Temperature: " + words[1] + Environment.NewLine); 

        }

        private void button2_Click(object sender, EventArgs e)
        {
            //dis
            log.Dis();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //con
            log.Con();

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
