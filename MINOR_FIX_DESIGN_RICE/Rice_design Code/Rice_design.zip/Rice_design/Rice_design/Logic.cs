﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excel = Microsoft.Office.Interop.Excel;
using System.Data.OleDb;
using System.Data;
using System.Windows.Forms;
using System.IO.Ports;
using System.Threading;
using System.IO;


namespace Rice_design
{
    class Logic
    {

        //COM3
        SerialPort Ard;

        public void Con()
        {
            Ard = new SerialPort("COM7", 9600);
            Ard.Open();
        }

        public void Dis()
        {

            Ard.Close();
        }

        public void Trans(out string count, out string[] words)
        {

            string se = "";
            se = Ard.ReadLine();
            se = se.Substring(0, se.Length - 2);
            words = se.Split(',');
            Form1 gui = new Form1();
            OleDbConnection MyConnection;
            OleDbCommand myCommand = new OleDbCommand();
            string sql = null;
            MyConnection = new OleDbConnection("provider=Microsoft.Jet.OLEDB.4.0;Data Source='D:\\Data.xls';Extended Properties=Excel 8.0;");
            MyConnection.Open();
            myCommand.Connection = MyConnection;
            count=DateTime.Now.ToString("h:mm:ss tt");
        
            sql = "Insert into [Sheet1$] (Log,Moisture,Humidity) Values ('" + count + "'," + words[0] + "," + words[1] + ")";
            myCommand.CommandText = sql;

                myCommand.ExecuteNonQuery();
 
            MyConnection.Close();

        }


    }
}
