﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Rice_design
{
    public partial class Form1 : Form
    {
        Logic log = new Logic();


        public static Form1 _Form1;
        public Form1()
        {
            InitializeComponent();
            _Form1 = this;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //trans

            log.Trans(out string count, out string[] words);

            richTextBox1.AppendText("\n" + count + " - " + "Moisture: " + words[0] + " Humidity: " + words[1] +"                                   "); 

        }

        private void button2_Click(object sender, EventArgs e)
        {
            //dis
            log.Dis();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //con
            log.Con();

        }
    }
}
